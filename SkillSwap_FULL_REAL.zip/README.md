# SkillSwap - Fullstack Skill Exchange Platform

## 🌐 Stack
- React + Tailwind (Frontend)
- Node.js + Express + MongoDB (Backend)
- JWT Auth, Coin Wallet System
- Razorpay-ready Payment Integration

## 🚀 Setup Instructions

### Prerequisites
- Node.js
- MongoDB Atlas account
- Razorpay account (optional)

### Step 1: Clone and Install
```bash
git clone https://github.com/your-username/skillswap.git
cd skillswap
```

### Step 2: Setup Backend
```bash
cd server
cp .env.example .env
npm install
npm start
```

### Step 3: Setup Frontend
```bash
cd ../client
npm install
npm start
```

### Step 4: Deploy
- Frontend ➜ Vercel
- Backend ➜ Render

## 🔐 Auth + Skills + Coin System
- Register/Login
- Add Skills Offered / Needed
- Post Task (with coin value)
- Coin deducted on task approval

---
